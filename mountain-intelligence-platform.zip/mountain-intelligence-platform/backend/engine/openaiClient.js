import OpenAI from "openai";

const hasKey = Boolean(process.env.OPENAI_API_KEY);
const client = hasKey ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

export async function askOpenAI(systemPrompt, userQuestion) {
  if (!client) {
    return `Demo mode: OPENAI_API_KEY is not set on the backend.\n\nQuestion received: ${userQuestion}\n\nNext action: add OPENAI_API_KEY in Render environment variables, then redeploy.`;
  }

  const completion = await client.chat.completions.create({
    model: process.env.OPENAI_MODEL || "gpt-4o-mini",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userQuestion }
    ],
    temperature: 0.3
  });

  return completion.choices?.[0]?.message?.content || "No response generated.";
}
