import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";

const router = express.Router();
const uploadDir = path.resolve("uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${Date.now()}-${safeName}`);
  }
});

const upload = multer({ storage });

router.post("/", upload.single("document"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No document uploaded." });

  res.json({
    message: "Document received.",
    filename: req.file.originalname,
    stored_as: req.file.filename,
    size_bytes: req.file.size,
    mimetype: req.file.mimetype
  });
});

export default router;
