import express from "express";
import { getCoachSystemPrompt } from "../coaches/prompts.js";
import { askOpenAI } from "../engine/openaiClient.js";

const router = express.Router();

router.post("/", async (req, res) => {
  const { coach_type = "executive", question = "" } = req.body || {};

  if (!question.trim()) {
    return res.status(400).json({ error: "Question is required." });
  }

  const systemPrompt = getCoachSystemPrompt(coach_type);
  const response = await askOpenAI(systemPrompt, question);

  res.json({ coach_type, response });
});

export default router;
