import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import coachRoutes from "./routes/coach.js";
import analyzeRoutes from "./routes/analyze.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 10000;

app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));
app.use(express.json({ limit: "2mb" }));
app.use("/uploads", express.static("uploads"));

app.get("/", (req, res) => {
  res.json({ app: "Mountain Intelligence Backend", version: "5.0.0", status: "running" });
});

app.get("/health", (req, res) => {
  res.json({ ok: true, service: "mountain-intelligence-backend" });
});

app.use("/coach", coachRoutes);
app.use("/analyze", analyzeRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Mountain Intelligence backend running on port ${PORT}`);
});
