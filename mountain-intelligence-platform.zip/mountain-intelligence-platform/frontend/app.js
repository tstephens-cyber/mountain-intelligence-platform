const BACKEND_URL = "https://mountain-intelligence-coach-backend.onrender.com";

const statusPill = document.getElementById("statusPill");
const fileInput = document.getElementById("fileInput");
const analyzeBtn = document.getElementById("analyzeBtn");
const analysisResult = document.getElementById("analysisResult");
const coachType = document.getElementById("coachType");
const coachQuestion = document.getElementById("coachQuestion");
const coachBtn = document.getElementById("coachBtn");
const coachAnswer = document.getElementById("coachAnswer");

function showResult(element, message) {
  element.classList.remove("hidden");
  element.textContent = message;
}

async function checkBackend() {
  try {
    const res = await fetch(`${BACKEND_URL}/health`);
    if (!res.ok) throw new Error("Backend unavailable");
    statusPill.textContent = "Backend connected";
    statusPill.className = "status-pill ok";
  } catch (error) {
    statusPill.textContent = "Backend not connected";
    statusPill.className = "status-pill bad";
  }
}

async function analyzeDocument() {
  const file = fileInput.files[0];
  if (!file) {
    showResult(analysisResult, "Please choose a document first.");
    return;
  }

  analyzeBtn.disabled = true;
  showResult(analysisResult, "Uploading document to Mountain Intelligence...");

  try {
    const formData = new FormData();
    formData.append("document", file);

    const res = await fetch(`${BACKEND_URL}/analyze`, {
      method: "POST",
      body: formData
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Upload failed");

    showResult(
      analysisResult,
      `✅ Document uploaded and stored.\n\nFile: ${data.filename}\nSize: ${data.size_bytes} bytes\n\nNext step: connect workbook parsing and branch context.`
    );
  } catch (error) {
    showResult(analysisResult, `Error analyzing document:\n\n${error.message}`);
  } finally {
    analyzeBtn.disabled = false;
  }
}

async function askCoach() {
  const type = coachType.value;
  const question = coachQuestion.value.trim();

  if (!question) {
    showResult(coachAnswer, "Please enter a question first.");
    return;
  }

  coachBtn.disabled = true;
  showResult(coachAnswer, "Calling Mountain Intelligence Coach...");

  try {
    const res = await fetch(`${BACKEND_URL}/coach`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ coach_type: type, question })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || data.message || "Backend error");

    const reply = data.response || data.answer || data.message || JSON.stringify(data, null, 2);
    showResult(coachAnswer, `${type.toUpperCase()} COACH:\n\n${reply}`);
  } catch (error) {
    showResult(coachAnswer, `Error connecting to Coach backend:\n\n${error.message}`);
  } finally {
    coachBtn.disabled = false;
  }
}

analyzeBtn.addEventListener("click", analyzeDocument);
coachBtn.addEventListener("click", askCoach);

document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => {
    coachQuestion.value = button.dataset.prompt;
    window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
  });
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("service-worker.js");
}

checkBackend();
