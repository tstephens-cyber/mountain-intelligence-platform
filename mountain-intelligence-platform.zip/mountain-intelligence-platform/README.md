# Mountain Intelligence 5.0

Installable PWA frontend plus Render-ready Node backend.

## Folder structure

- `frontend/` — PWA app files
- `backend/` — Express API for Coach and document upload
- `render.yaml` — Render deployment config

## Frontend

Open `frontend/index.html` locally or deploy the folder with GitHub Pages, Netlify, Vercel, or any static host.

The frontend currently points to:

`https://mountain-intelligence-coach-backend.onrender.com`

To change it, edit `frontend/app.js`.

## Backend local setup

```bash
cd backend
npm install
cp .env.example .env
npm start
```

Add your real `OPENAI_API_KEY` in Render or `.env`.

## Render deployment

1. Push this repo to GitHub.
2. In Render, create a new Blueprint or Web Service.
3. Use `backend` as the root directory if creating manually.
4. Add environment variable `OPENAI_API_KEY`.
5. Deploy.

## Next build steps

1. Add real Excel/PDF parsing.
2. Store branch context by upload session.
3. Add authenticated users.
4. Add KPI dashboard and P&L forensic engine.
